package com.thdwjddussapplication.app.modules.one.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.thdwjddussapplication.app.R
import com.thdwjddussapplication.app.appcomponents.base.BaseActivity
import com.thdwjddussapplication.app.databinding.ActivityOneBinding
import com.thdwjddussapplication.app.modules.one.`data`.viewmodel.OneVM
import com.thdwjddussapplication.app.modules.one1.ui.One1Activity
import kotlin.String
import kotlin.Unit

class OneActivity : BaseActivity<ActivityOneBinding>(R.layout.activity_one) {
  private val viewModel: OneVM by viewModels<OneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.oneVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = One1Activity.getIntent(this, null)
      startActivity(destIntent)
      finish()
      }, 3000)
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "ONE_ACTIVITY"

    }
  }

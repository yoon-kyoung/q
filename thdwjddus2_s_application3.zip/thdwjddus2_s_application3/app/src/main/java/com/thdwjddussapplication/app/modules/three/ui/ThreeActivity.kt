package com.thdwjddussapplication.app.modules.three.ui

import androidx.activity.viewModels
import com.thdwjddussapplication.app.R
import com.thdwjddussapplication.app.appcomponents.base.BaseActivity
import com.thdwjddussapplication.app.databinding.ActivityThreeBinding
import com.thdwjddussapplication.app.modules.three.`data`.viewmodel.ThreeVM
import kotlin.String
import kotlin.Unit

class ThreeActivity : BaseActivity<ActivityThreeBinding>(R.layout.activity_three) {
  private val viewModel: ThreeVM by viewModels<ThreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.threeVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "THREE_ACTIVITY"

  }
}

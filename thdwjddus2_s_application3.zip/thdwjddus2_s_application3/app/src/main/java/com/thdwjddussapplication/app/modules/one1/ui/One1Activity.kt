package com.thdwjddussapplication.app.modules.one1.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.thdwjddussapplication.app.R
import com.thdwjddussapplication.app.appcomponents.base.BaseActivity
import com.thdwjddussapplication.app.databinding.ActivityOne1Binding
import com.thdwjddussapplication.app.modules.one1.`data`.viewmodel.One1VM
import kotlin.String
import kotlin.Unit

class One1Activity : BaseActivity<ActivityOne1Binding>(R.layout.activity_one1) {
  private val viewModel: One1VM by viewModels<One1VM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.one1VM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ONE1ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, One1Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}

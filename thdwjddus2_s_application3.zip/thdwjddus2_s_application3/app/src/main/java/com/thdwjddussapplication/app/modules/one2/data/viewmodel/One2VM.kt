package com.thdwjddussapplication.app.modules.one2.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.thdwjddussapplication.app.modules.one2.`data`.model.One2Model
import org.koin.core.KoinComponent

class One2VM : ViewModel(), KoinComponent {
  val one2Model: MutableLiveData<One2Model> = MutableLiveData(One2Model())

  var navArguments: Bundle? = null
}

package com.thdwjddussapplication.app.modules.two.ui

import androidx.activity.viewModels
import com.thdwjddussapplication.app.R
import com.thdwjddussapplication.app.appcomponents.base.BaseActivity
import com.thdwjddussapplication.app.databinding.ActivityTwoBinding
import com.thdwjddussapplication.app.modules.two.`data`.viewmodel.TwoVM
import kotlin.String
import kotlin.Unit

class TwoActivity : BaseActivity<ActivityTwoBinding>(R.layout.activity_two) {
  private val viewModel: TwoVM by viewModels<TwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.twoVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "TWO_ACTIVITY"

  }
}

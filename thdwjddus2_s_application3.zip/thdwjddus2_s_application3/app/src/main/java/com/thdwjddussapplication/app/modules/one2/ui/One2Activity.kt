package com.thdwjddussapplication.app.modules.one2.ui

import androidx.activity.viewModels
import com.thdwjddussapplication.app.R
import com.thdwjddussapplication.app.appcomponents.base.BaseActivity
import com.thdwjddussapplication.app.databinding.ActivityOne2Binding
import com.thdwjddussapplication.app.modules.one2.`data`.viewmodel.One2VM
import kotlin.String
import kotlin.Unit

class One2Activity : BaseActivity<ActivityOne2Binding>(R.layout.activity_one2) {
  private val viewModel: One2VM by viewModels<One2VM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.one2VM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ONE2ACTIVITY"

  }
}

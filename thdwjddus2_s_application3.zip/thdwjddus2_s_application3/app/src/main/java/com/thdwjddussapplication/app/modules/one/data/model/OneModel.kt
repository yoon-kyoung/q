package com.thdwjddussapplication.app.modules.one.`data`.model

import com.thdwjddussapplication.app.R
import com.thdwjddussapplication.app.appcomponents.di.MyApp
import kotlin.String

data class OneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtOne: String? = MyApp.getInstance().resources.getString(R.string.lbl5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl6)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup2256: String? = MyApp.getInstance().resources.getString(R.string.lbl_pin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtThree: String? = MyApp.getInstance().resources.getString(R.string.lbl7)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFour: String? = MyApp.getInstance().resources.getString(R.string.lbl8)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwentyFourValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwentySixValue: String? = null
)
